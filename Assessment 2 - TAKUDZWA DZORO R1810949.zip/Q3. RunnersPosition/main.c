#include <stdio.h>
#include <stdlib.h>

void dataEntry()
{

    char name[20], race[20];
    int time, position;
    printf("enter race name: \n");
    scanf("%s",&race);
    printf("enter racer name: \n");
    scanf("%s",&name);
    printf("enter time taken: \n");
    scanf("%d",&time);
    printf("enter racer position: \n");
    scanf("%d",&position);

    printf("Name of Race: %s \n",race);
    printf("Name of Runner: %s \n",name);
    printf("Time taken: %d \n",time);
    printf("Position of Runner: %d \n",position);

}

int main()
{

    dataEntry();

    return 0;
}
