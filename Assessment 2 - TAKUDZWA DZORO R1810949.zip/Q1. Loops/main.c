#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value;
    int i=6;
    printf("enter val: \n");
    scanf("%d",&value);

    while(i<value)
    {
        printf("value: %d is a multiple of 6.\n",i);
        i+=6;
    }

    return 0;
}
