#include <stdio.h>
#include <stdlib.h>

void menu()
{
    int choice;
    printf("1. Rectangle\n2. Square\nSelect your choice!\n");
    scanf("%d",&choice);

    if (choice == 1)
    {
        rectangle();
    }
    else if (choice == 2)
    {
        square();
    }
    else printf("invalid entry\n");


}

void rectangle(int l, int w)
{

    printf("enter length: \n");
    scanf("%d",&l);
    printf("enter width: \n");
    scanf("%d",&w);
    printf("area of a rectangle is: %d", (l*w));

}

void square(int s)
{
    printf("enter side: \n");
    scanf("%d",&s);
    printf("area of a square is: %d", (s*s));

}

int main()
{
    menu();

    return 0;
}
