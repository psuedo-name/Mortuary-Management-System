#include <stdio.h>
#include <stdlib.h>

int main()
{
    int month,day,dayx=31,dayy=30,dayz=28;//declaring variables and assigning number of days

    printf("enter month number[1-12]: ");
    scanf("%d",&month);//entering number of months
//for all months with 31 days
    if(month==1 || month == 3 || month == 5 || month == 7 || month == 8|| month == 10 || month == 12 )
    {
        printf("enter day: ");
        scanf("%d",&day);
        dayx=dayx-day;
        printf("Day: [%d]\nMonth: [%d]\nDays left[%d]\n",day,month,dayx);
    }

//february, for all months with 28 days
    else if (month == 2 )
    {
        printf("enter day: ");
        scanf("%d",&day);
        dayz=dayz-day;
        printf("Day: [%d]\nMonth: [%d]\nDays left[%d]\n",day,month,dayz);
    }

    //for all months with 30 days
    else if (month == 4 || month == 6 || month == 9 || month == 11)
    {
        printf("enter day: ");
        scanf("%d",&day);
        dayy=dayy-day;
        printf("Day: [%d]\nMonth: [%d]\nDays left[%d]\n",day,month,dayy);
    }

    //invalid option, programme terminates
    else printf("invalid entry \n");

    return 0;
}
