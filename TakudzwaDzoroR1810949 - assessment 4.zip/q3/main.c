#include <stdio.h>
#include <stdlib.h>

int main()
{
    int arrNumbers[]={1,2,3,4,5};
    char arrCharacters[]={'w','o','r','d','X'};
    int i;

    printf("characters\n");
    for(i=0;i<5;i++)
    {
        printf("index [%d] charac[%c]\n",i,arrCharacters[i]);
    }

    printf("\n\nnumbers\n");


    for(i=0;i<5;i++)
    {
        printf("index [%d] value [%d]\n",i,arrNumbers[i]);
    }

    return 0;
}
