#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fr;//file pounter
   char name[40];
   int age,i;

   //for opening a file and writing to a file
   fr = fopen("welcome.txt", "w");
   for(i=1;i<=5;i++){
   printf("Enter a name and a age:");
   scanf("%s%d", name, &age); /*read from keyboard*/

   fprintf(fr, "%s %d", name, age); /*  write to file*/
   }
   fclose(fr);


   fr = fopen("welcome.txt", "r");
   printf("name\tage\n");
   for(i=1;i<=5;i++)
   {
   fscanf(fr, "%s:\t\t\n%d: ", name, &age); /*read from file*/
   printf("%s\t\t%d\n", name, age); /*display on screen*/
   }
   fclose(fr);

    return 0;
}
