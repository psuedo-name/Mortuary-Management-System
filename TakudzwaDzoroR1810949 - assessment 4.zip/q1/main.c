#include <stdio.h>
#include <stdlib.h>

void avg();
void inputMark();

int i,subjects,total=0,mark[],average=0;//declaring variables
int main()
{
    inputMark();//calling the inputmark fuction
    avg();//calling the average fuction
    return 0;
}


 void inputMark()
 {
     printf("enter number of subjects: ");
     scanf("%d",&subjects);//entering total number of subjects

     for(i=1;i<=subjects;i++)//for loop for entering number of subjects and calculating their total
     {
         printf("enter mark of subject [%d]:",i);
         scanf("%d",&mark[i]);
         total+=mark[i];//summing up the total mark
     }
     for(i=1;i<=subjects;i++)
     {
        printf("Subject: [%d] Mark:[%d]\n",i,mark[i]);
     }
     printf("total marks: [%d]",total);//displaying the total mark
 }

 void avg()
 {
    average=total/subjects;
    printf("average is: %d",average);
}
